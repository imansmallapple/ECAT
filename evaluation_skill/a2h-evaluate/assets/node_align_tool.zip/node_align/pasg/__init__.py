"""PASG: Platform-Agnostic Semantic Graph for cross-platform code migration analysis.

CodeGraph-only edition: both Android and HarmonyOS are parsed by the `codegraph`
CLI into the same .codegraph/codegraph.db schema. No ArkAnalyzer dependency.
"""

from .kg_models import Entity, Relation, EntityType, RelationType, Graph, SourceLocation
from .abstractor import PasgAbstractor
from .alignment import PasgAligner
from .kg_pipeline import (
    build_graph, build_android_graph, build_harmony_graph, run_pasg,
)
