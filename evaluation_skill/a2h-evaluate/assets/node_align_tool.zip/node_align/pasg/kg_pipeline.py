"""PASG pipeline — CodeGraph-only (Android + HarmonyOS).

Both platforms are parsed by the **same** `codegraph` CLI into the **same**
``.codegraph/codegraph.db`` schema (``nodes`` / ``edges`` tables). This module
reads that SQLite DB into the KG Entity/Relation model, parameterized only by
``platform`` ("android" / "harmonyos").

This replaces the old two-tool design (codegraph for Android + ArkAnalyzer for
HarmonyOS). Benefits:

  * One extraction tool, one reader, one schema → symmetric and simpler.
  * HarmonyOS cross-class ``calls`` / ``instantiates`` edges come for free —
    no DevEco Studio SDK required (ArkAnalyzer produced an empty call graph
    without it).
  * ArkTS ``@Component struct`` / ``@Entry`` / ``@CustomDialog`` / ``@State``
    decorators land directly in the ``nodes.decorators`` JSON column, which the
    HarmonyOS classifier reads verbatim.
  * Android inheritance (``extends`` / ``implements`` edges) is aggregated onto
    each entity, so the Android classifier's inheritance branches — and its
    platform-friction exclusions (BroadcastReceiver, AsyncTask, …) — finally
    fire (the old reader dropped this information).

No ArkAnalyzer, no DevEco SDK, no Node toolchain beyond the codegraph CLI.
"""

from __future__ import annotations
import json
import os
import re
import sqlite3
from pathlib import Path

from .kg_models import (
    Entity, EntityType, Relation, RelationType, Graph, SourceLocation,
)
from .abstractor import PasgAbstractor
from .alignment import PasgAligner

CODEGRAPH_DB_REL = os.path.join(".codegraph", "codegraph.db")

# Architectural + edge-participating node kinds we load from the DB.
# `struct` is ArkTS-only (the @Component struct); it is absent from Kotlin DBs,
# so this single list works for both platforms.
_DB_KINDS = ("class", "interface", "struct", "function", "method", "file", "enum")

# DB node kind → KG EntityType
_KIND_TO_TYPE = {
    "class": EntityType.CLASS,
    "interface": EntityType.CLASS,
    "struct": EntityType.CLASS,
    "function": EntityType.FUNCTION,
    "method": EntityType.FUNCTION,
    "file": EntityType.FILE,
    "enum": EntityType.ENUM,
}

# DB edge kind → KG RelationType
_EDGE_KIND_TO_TYPE = {
    "contains": RelationType.CONTAINS,
    "calls": RelationType.CALLS,
    "instantiates": RelationType.CALLS,     # treat instantiation as a call edge
    "extends": RelationType.INHERITS_FROM,
    "implements": RelationType.INHERITS_FROM,
    "references": RelationType.REFERENCES,
}


def _loc(file_path: str, start_line: int, end_line: int | None) -> SourceLocation | None:
    if not file_path:
        return None
    return SourceLocation(file_path=file_path, start_line=start_line or 0,
                          end_line=end_line or start_line or 0)


def _parse_decorators(raw) -> list[str]:
    """codegraph stores decorators as a JSON array string, e.g. '["Entry","Component"]'."""
    if not raw:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw]
    try:
        v = json.loads(raw)
        return [str(x) for x in v] if isinstance(v, list) else [str(v)]
    except (ValueError, TypeError):
        # fall back to bare comma/space split
        return [t.strip().lstrip("@") for t in re.split(r"[,\s]+", str(raw)) if t.strip()]


# ═══════════════════════════════════════════════════════════════════════
# Inheritance back-fill from source (ArkTS only)
# ═══════════════════════════════════════════════════════════════════════
# codegraph emits `extends` edges for Kotlin but NOT for ArkTS (HarmonyOS DBs
# only carry `implements`). To keep the HarmonyOS classifier's extends-branches
# working (ServiceExtAbility / BackupExtensionAbility / BasicDataSource), we
# back-fill supers from the class declaration source for ArkTS class/interface
# entities that have no known supers yet. File contents are cached per-file.

_SUPER_RE = re.compile(r"\bextends\s+([A-Za-z_$][\w$.]*)")
_IMPL_RE = re.compile(r"\bimplements\s+([^\{]+)")


class _SourceCache:
    def __init__(self, project_dir: str):
        self._root = Path(project_dir)
        self._files: dict[str, list[str] | None] = {}

    def _lines(self, rel_path: str) -> list[str] | None:
        cached = self._files.get(rel_path)
        if cached is not None:
            return cached
        fp = self._root / rel_path
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
            lines = text.splitlines()
        except OSError:
            lines = None
        self._files[rel_path] = lines
        return lines

    def supers_at(self, rel_path: str, start_line: int) -> list[str]:
        """Read the declaration at start_line and extract extends/implements names."""
        lines = self._lines(rel_path)
        if not lines:
            return []
        # declaration may span a few lines; scan a small window from start_line-1
        lo = max(0, (start_line or 1) - 1)
        hi = min(len(lines), lo + 6)
        window = "\n".join(lines[lo:hi])
        names: list[str] = []
        m = _SUPER_RE.search(window)
        if m:
            names.append(m.group(1).split(".")[-1])
        m = _IMPL_RE.search(window)
        if m:
            names.extend(p.strip().split(".")[-1]
                         for p in m.group(1).split(",") if p.strip())
        return names


# ═══════════════════════════════════════════════════════════════════════
# Core: read a codegraph DB → KG Graph
# ═══════════════════════════════════════════════════════════════════════

def build_graph(project_dir: str, platform: str) -> Graph:
    """Read ``<project_dir>/.codegraph/codegraph.db`` into a KG Graph.

    ``platform`` is "android" or "harmonyos" — only affects the ``language``
    tag, decorator/annotation wiring, and whether inheritance is back-filled
    from source. The DB schema and reader are identical for both.
    """
    db_path = os.path.join(project_dir, CODEGRAPH_DB_REL)
    language = "kotlin" if platform == "android" else "arkts"
    db = sqlite3.connect(db_path)
    db.row_factory = sqlite3.Row
    g = Graph()

    # ── entities ──
    for r in db.execute(
        f"SELECT * FROM nodes WHERE kind IN ({','.join('?' * len(_DB_KINDS))}) ORDER BY id",
        _DB_KINDS,
    ):
        etype = _KIND_TO_TYPE.get(r["kind"])
        if etype is None:
            continue
        decs = _parse_decorators(r["decorators"])
        loc = _loc(r["file_path"], r["start_line"], r["end_line"])
        props = {
            "visibility": r["visibility"],
            "is_exported": bool(r["is_exported"]) if r["is_exported"] is not None else False,
            "decorators": decs,
            "annotations": decs,          # Android classifier reads "annotations"
            "inheritance": "",            # aggregated from edges below
            "extends": [],                # aggregated from edges / source below
        }
        g.add_entity(Entity(
            id=r["id"], type=etype, name=r["name"], kind=r["kind"],
            location=loc, language=language, properties=props,
        ))

    # ── relations ──
    for r in db.execute("SELECT * FROM edges ORDER BY source, target, kind"):
        rtype = _EDGE_KIND_TO_TYPE.get(r["kind"])
        if rtype is None:
            continue
        g.add_relation(Relation(
            source_id=r["source"], target_id=r["target"], type=rtype, kind=r["kind"],
        ))

    db.close()

    # ── aggregate inheritance edges onto entities (feeds the classifiers) ──
    _aggregate_inheritance(g)

    # ── back-fill ArkTS extends from source (codegraph emits no ArkTS extends edges) ──
    if platform == "harmonyos":
        _backfill_supers_from_source(g, project_dir)

    return g


def _aggregate_inheritance(g: Graph) -> None:
    """For each entity, collect the names of entities it extends/implements.

    Populates ``properties['inheritance']`` (space-joined, for the Android
    classifier which regex-scans a string) and ``properties['extends']``
    (list, for the HarmonyOS classifier).
    """
    for rel in g.relations:
        if rel.type != RelationType.INHERITS_FROM:
            continue
        src = g.get_entity(rel.source_id)
        tgt = g.get_entity(rel.target_id)
        if not src or not tgt:
            continue
        sup = tgt.name.split(".")[-1]
        if sup not in src.properties["extends"]:
            src.properties["extends"].append(sup)
        if sup and sup not in src.properties["inheritance"]:
            src.properties["inheritance"] = (src.properties["inheritance"] + " " + sup).strip()


def _backfill_supers_from_source(g: Graph, project_dir: str) -> None:
    """For ArkTS class/interface entities with no known supers, read the
    declaration source and recover extends/implements names."""
    cache = _SourceCache(project_dir)
    for ent in g.entities.values():
        if ent.type != EntityType.CLASS:
            continue
        if ent.properties.get("extends"):
            continue  # already known from edges
        if not ent.location:
            continue
        names = cache.supers_at(ent.location.file_path, ent.location.start_line)
        if not names:
            continue
        ent.properties["extends"] = names
        joined = " ".join(names)
        if joined and joined not in ent.properties["inheritance"]:
            ent.properties["inheritance"] = (ent.properties["inheritance"] + " " + joined).strip()


# ═══════════════════════════════════════════════════════════════════════
# Platform-specific entry points (match the old public API)
# ═══════════════════════════════════════════════════════════════════════

def build_android_graph(project_dir: str) -> Graph:
    """Read the Android project's codegraph DB → KG Graph."""
    return build_graph(project_dir, "android")


def build_harmony_graph(project_dir: str) -> Graph:
    """Read the HarmonyOS project's codegraph DB → KG Graph.

    Replaces the old ArkAnalyzer-JSON reader. Same signature contract the
    rest of PASG expects, but now takes the project directory (which must
    contain ``.codegraph/codegraph.db``) instead of an export JSON path.
    """
    return build_graph(project_dir, "harmonyos")


# ═══════════════════════════════════════════════════════════════════════
# Full pipeline
# ═══════════════════════════════════════════════════════════════════════

def run_pasg(android_project_dir: str, harmony_project_dir: str,
             name_mappings: dict | None = None, no_bootstrap: bool = False,
             verbose: bool = True,
             node_similarity_threshold: float = 0.30) -> dict:
    """Run full PASG: CodeGraph(Android) + CodeGraph(HarmonyOS) → alignment.

    Both projects must already contain ``.codegraph/codegraph.db`` (produce one
    with ``codegraph init`` — see ``run_alignment.py``). By default, auto-runs
    bootstrap to derive cross-platform name mappings from the two KG graphs;
    extra ``name_mappings`` are merged on top.
    """
    from .alignment import set_app_mappings
    from .bootstrap import bootstrap_from_kg

    if verbose:
        print("=" * 60)
        print("PASG: CodeGraph(Android) + CodeGraph(HarmonyOS)")
        print("=" * 60)

    if verbose:
        print("\n[1] Android (CodeGraph)...")
    akg = build_android_graph(android_project_dir)
    if verbose:
        print(f"  {akg.entity_count()} entities, {akg.relation_count()} relations")

    if verbose:
        print("\n[2] HarmonyOS (CodeGraph)...")
    hkg = build_harmony_graph(harmony_project_dir)
    if verbose:
        print(f"  {hkg.entity_count()} entities, {hkg.relation_count()} relations")

    if not no_bootstrap:
        if verbose:
            print("\n[2b] Auto-bootstrap name mappings...")
        bs_mappings = bootstrap_from_kg(akg, hkg)
        if name_mappings:
            bs_mappings.update(name_mappings)
        set_app_mappings(bs_mappings)
        if verbose:
            print(f"  Bootstrap generated {len(bs_mappings)} mappings")

    if verbose:
        print("\n[3] PASG Abstraction + Alignment...")
    abs1 = PasgAbstractor()
    ps = abs1.abstract(akg, "android")
    pt = abs1.abstract(hkg, "harmonyos")
    if verbose:
        print(f"  Src: {ps.node_count()}n/{ps.edge_count()}e  "
              f"Tgt: {pt.node_count()}n/{pt.edge_count()}e")

    al = PasgAligner(
        node_similarity_threshold=node_similarity_threshold,
        name_mappings=name_mappings,
    )
    result = al.align(ps, pt, verbose=verbose)

    return {
        "android_entities": akg.entity_count(),
        "android_relations": akg.relation_count(),
        "harmony_entities": hkg.entity_count(),
        "harmony_relations": hkg.relation_count(),
        "pasg_src_nodes": ps.node_count(),
        "pasg_src_edges": ps.edge_count(),
        "pasg_tgt_nodes": pt.node_count(),
        "pasg_tgt_edges": pt.edge_count(),
        "aligned_pairs": len(result.aligned_pairs),
        "node_retention": result.scores["node_retention"],
        "edge_retention": result.scores["edge_retention"],
        "path_retention": result.scores["path_retention"],
        "overall_score": result.equivalence_score,
        "node_similarity_threshold": node_similarity_threshold,
        "pasg_src": ps, "pasg_tgt": pt, "alignment_result": result,
    }
