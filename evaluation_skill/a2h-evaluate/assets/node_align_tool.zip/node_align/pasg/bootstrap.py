"""Auto-generate app-specific PASG configuration from two codebases.

Pure static analysis — no LLM, no manual labeling.  Uses:
  1. Name intersection to discover common entity/data model classes
  2. Suffix rules to infer cross-platform name mappings
  3. Token overlap for remaining unknown pairs
"""

from __future__ import annotations
import os
import re
import json
from pathlib import Path
from typing import Optional


def bootstrap(android_dir: str, harmony_dir: str,
              output_path: Optional[str] = None,
              verbose: bool = True) -> dict:
    """Auto-generate app-specific config from two codebases.

    Returns a config dict with:
      - entity_names: list of common data model class names
      - name_mappings: dict of android_name → harmony_name
    """
    if verbose:
        print("Bootstrapping PASG configuration...")
        print(f"  Android:   {android_dir}")
        print(f"  HarmonyOS: {harmony_dir}")

    # ── Step 1: Extract all class names from both codebases ──
    android_names = _extract_class_names(android_dir, ".kt",
        r'(?:class|object|interface|enum\s+class)\s+(\w+)')
    harmony_names = _extract_class_names(harmony_dir, ".ets",
        r'(?:struct|class|interface)\s+(\w+)')

    if verbose:
        print(f"  Android classes:    {len(android_names)}")
        print(f"  HarmonyOS classes:  {len(harmony_names)}")

    # ── Step 2: Auto-discover entity names ──
    entity_names = _discover_entities(android_names, harmony_names)

    if verbose:
        print(f"  Auto-detected entities: {len(entity_names)}")

    # ── Step 3: Auto-generate cross-platform name mappings ──
    name_mappings = _discover_name_mappings(android_names, harmony_names)

    if verbose:
        print(f"  Auto-detected name pairs: {len(name_mappings)}")

    config = {
        "app_name": _infer_app_name(android_dir),
        "entity_names": sorted(entity_names),
        "name_mappings": name_mappings,
        "android_source": android_dir,
        "harmony_source": harmony_dir,
        "auto_generated": True,
    }

    # ── Step 4: Write config ──
    if output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        if verbose:
            print(f"  Config written to: {output_path}")

    return config


def _extract_class_names(root: str, ext: str, pattern: str) -> set[str]:
    """Extract all class/struct/interface names from a codebase."""
    names: set[str] = set()
    class_pat = re.compile(pattern)

    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames
                      if d not in ("node_modules", ".git", "build",
                                   "oh_modules", "res", "resources")]
        for fn in filenames:
            if fn.endswith(ext):
                fp = os.path.join(dirpath, fn)
                try:
                    source = Path(fp).read_text(encoding="utf-8")
                except Exception:
                    continue
                for m in class_pat.finditer(source):
                    names.add(m.group(1))
    return names


def _discover_entities(android_names: set[str], harmony_names: set[str]) -> list[str]:
    """Auto-discover entity/data model class names from name intersection.

    Strategy:
      1. Find names in BOTH codebases (intersection)
      2. Remove platform-specific types (Activity, Service, etc.)
      3. Remove naming convention types (ViewModel, Dao, Helper, etc.)
      4. Remove known non-entity classes (Config, Constants, etc.)
      5. Remaining intersection → likely entities
    """
    common = android_names & harmony_names

    # Platform-type suffixes to exclude
    platform_suffixes = {
        "Activity", "Fragment", "Service", "Receiver", "Provider",
        "Application", "Adapter", "Database",
    }

    # Convention suffixes to exclude
    convention_suffixes = {
        "ViewModel", "Dao", "Helper", "Utils", "Manager", "Handler",
        "Listener", "Observer", "Factory", "Builder", "Controller",
        "Module", "Decoder", "Encoder", "Fetcher", "Parser",
    }

    # Known utility/config names
    known_utility = {
        "Config", "Constants", "AppRouter", "PermissionHelper",
        "GlobalState", "EntryAbility", "EntryBackupAbility",
    }

    entities = []
    for name in sorted(common):
        # Skip short names (likely common words)
        if len(name) <= 2:
            continue

        # Skip platform-type suffixes
        if _ends_with_any(name, platform_suffixes):
            continue

        # Skip convention suffixes
        if _ends_with_any(name, convention_suffixes):
            continue

        # Skip known utilities
        if name in known_utility:
            continue

        # Skip if starts with typical non-entity prefixes
        if name.startswith("I") and name[1].isupper():
            continue  # Interface names like IDataSource

        entities.append(name)

    return entities


def _discover_name_mappings(android_names: set[str],
                             harmony_names: set[str]) -> dict[str, str]:
    """Auto-generate cross-platform name mappings.

    Strategy (ordered):
      1. Exact same name → direct match
      2. XxxActivity → XxxPage
      3. XxxActivity → Xxx (fallback: strip suffix and find match)
      4. XxxAdapter → XxxDataSource
      5. XxxAdapter → Xxx (fallback)
      6. Token overlap for remaining names
    """
    mappings: dict[str, str] = {}
    remaining_android = set(android_names)
    remaining_harmony = set(harmony_names)

    # Rule 1: Exact same name (exclude semantically false matches)
    _SAME_NAME_BLACKLIST = {"App"}  # Android Application vs HarmonyOS dummy bridge
    for name in sorted(android_names & harmony_names):
        if name in _SAME_NAME_BLACKLIST:
            continue
        mappings[name] = name
        remaining_android.discard(name)
        remaining_harmony.discard(name)

    # Transformation rules: (android_suffix, harmony_suffix, harmony_alt_suffix)
    suffix_rules = [
        ("Activity", "Page", ""),        # XxxActivity → XxxPage or Xxx
        ("Fragment", "Component", ""),   # XxxFragment → XxxComponent or Xxx
        ("Service", "Ability", ""),      # XxxService → XxxAbility
        ("Receiver", "Handler", ""),     # XxxReceiver → XxxHandler
        ("Provider", "Provider", ""),    # XxxProvider → XxxProvider
    ]

    for a_suffix, h_suffix, h_alt in suffix_rules:
        for a_name in sorted(remaining_android):
            if not a_name.endswith(a_suffix):
                continue
            if len(a_name) <= len(a_suffix):
                continue

            stem = a_name[:-len(a_suffix)]

            # Try: stem + h_suffix
            candidate = stem + h_suffix
            if candidate in remaining_harmony:
                mappings[a_name] = candidate
                remaining_android.discard(a_name)
                remaining_harmony.discard(candidate)
                continue

            # Try: just stem
            if h_alt == "" and stem in remaining_harmony:
                mappings[a_name] = stem
                remaining_android.discard(a_name)
                remaining_harmony.discard(stem)

    # Rule 6: Token overlap (stemmed + raw Jaccard, pick best)
    for a_name in sorted(remaining_android):
        a_tokens = _tokenize(a_name)
        a_stems = _tokenize_stems(a_name)
        best_h = None
        best_score = 0.0
        for h_name in sorted(remaining_harmony):
            h_tokens = _tokenize(h_name)
            h_stems = _tokenize_stems(h_name)
            raw_common = len(a_tokens & h_tokens)
            raw_total = len(a_tokens | h_tokens)
            raw = raw_common / raw_total if raw_total > 0 else 0
            stem_common = len(a_stems & h_stems)
            stem_total = len(a_stems | h_stems)
            stem = stem_common / stem_total if stem_total > 0 else 0
            score = max(raw, stem)
            if score > best_score and score > 0.45:
                best_score = score
                best_h = h_name
        if best_h:
            mappings[a_name] = best_h
            remaining_harmony.discard(best_h)

    return mappings


# ── helpers ─────────────────────────────────────────────────────────────

def _stem_token(word: str) -> str:
    """Lightweight stem: 'sorting'→'sort', 'grouping'→'group'."""
    w = word.lower()
    if len(w) <= 4:
        return w
    if w.endswith("ing") and len(w) > 5:
        stem = w[:-3]
        if len(stem) >= 3 and stem[-1] == stem[-2]:
            stem = stem[:-1]
        return stem
    return w


def _tokenize(name: str) -> set[str]:
    """Tokenize camelCase/PascalCase name into lowercase tokens."""
    tokens = set()
    words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]+|\d+', name)
    for w in words:
        if len(w) > 1:
            tokens.add(w.lower())
    return tokens


def _tokenize_stems(name: str) -> set[str]:
    """Tokenize and apply lightweight stemming (sorting→sort, grouping→group)."""
    tokens = set()
    words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]+|\d+', name)
    for w in words:
        wl = w.lower()
        if len(wl) > 1:
            tokens.add(_stem_token(wl))
    return tokens


def _ends_with_any(name: str, suffixes: set[str]) -> bool:
    for s in suffixes:
        if name.endswith(s):
            return True
    return False


def _infer_app_name(android_dir: str) -> str:
    """Infer app name from project structure."""
    parts = Path(android_dir).parts
    for i, p in enumerate(parts):
        if p.lower() in ("kotlin", "java") and i + 2 < len(parts):
            return parts[i + 2]
    return "unknown-app"


# ═══════════════════════════════════════════════════════════════════════
# Bootstrap from KG (Entity/Relation Graph) — integrated into run_pasg()
# ═══════════════════════════════════════════════════════════════════════

def bootstrap_from_kg(android_kg, harmony_kg) -> dict[str, str]:
    """Auto-generate cross-platform name mappings from loaded KG graphs.

    Extracts class names from both KG Entity/Relation graphs and applies
    suffix rules + token overlap, same logic as bootstrap() but operates
    on in-memory KG objects instead of source directories.
    """
    from .kg_models import EntityType

    android_names = set()
    harmony_names = set()

    for eid, ent in android_kg.entities.items():
        if ent.type == EntityType.CLASS:
            android_names.add(ent.name)

    for eid, ent in harmony_kg.entities.items():
        if ent.type == EntityType.CLASS:
            harmony_names.add(ent.name)

    return _discover_name_mappings(android_names, harmony_names)


# ═══════════════════════════════════════════════════════════════════════
# Load config and apply to parsers/alignment
# ═══════════════════════════════════════════════════════════════════════

def load_config(config_path: str) -> dict:
    """Load a bootstrap config file."""
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def apply_config_to_parser(config: dict):
    """Given a config dict, return (entity_names, name_mappings)."""
    return (
        config.get("entity_names", []),
        config.get("name_mappings", {}),
    )
