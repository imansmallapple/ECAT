"""PASG data models: platform-agnostic and platform-specific node/edge types."""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════
# PASG platform-agnostic node types
# ═══════════════════════════════════════════════════════════════════════

class PasgNodeType(str, Enum):
    SCREEN = "Screen"
    DATA_SOURCE = "DataSource"
    STATE_CONTAINER = "StateContainer"
    EVENT_HANDLER = "EventHandler"
    BACKGROUND_TASK = "BackgroundTask"
    TRANSFORMER = "Transformer"
    GATEWAY = "Gateway"


# ═══════════════════════════════════════════════════════════════════════
# PASG platform-agnostic edge types
# ═══════════════════════════════════════════════════════════════════════

class PasgEdgeType(str, Enum):
    RENDERS = "renders"               # Screen renders state
    TRIGGERS = "triggers"             # Event triggers screen update
    OBSERVES = "observes"             # StateContainer observes DataSource
    DELEGATES = "delegates"           # Screen delegates to EventHandler
    SCHEDULES = "schedules"           # BackgroundTask schedules Gateway
    TRANSFORMS = "transforms"         # Transformer processes data
    PROPAGATES = "propagates"         # State propagation between containers


# ═══════════════════════════════════════════════════════════════════════
# Platform-specific node types (Android)
# ═══════════════════════════════════════════════════════════════════════

class AndroidNodeType(str, Enum):
    ACTIVITY = "Activity"
    FRAGMENT = "Fragment"
    VIEW_MODEL = "ViewModel"
    SERVICE = "Service"
    JOB_SERVICE = "JobService"
    BROADCAST_RECEIVER = "BroadcastReceiver"
    APP_WIDGET = "AppWidgetProvider"
    ROOM_DATABASE = "RoomDatabase"
    ROOM_DAO = "RoomDao"
    ROOM_ENTITY = "RoomEntity"
    RETROFIT_API = "RetrofitApi"
    ADAPTER = "RecyclerViewAdapter"
    DATA_CLASS = "DataClass"
    HELPER = "Helper"
    CUSTOM_VIEW = "CustomView"
    APPLICATION = "Application"
    SHARED_PREFS = "SharedPreferences"


# ═══════════════════════════════════════════════════════════════════════
# Platform-specific node types (HarmonyOS)
# ═══════════════════════════════════════════════════════════════════════

class HarmonyNodeType(str, Enum):
    ENTRY_PAGE = "EntryPage"
    COMPONENT = "Component"
    VIEW_MODEL = "ViewModel"
    SERVICE_EXT = "ServiceExtAbility"
    RDB_STORE = "RdbStore"
    DAO = "Dao"
    ENTITY = "Entity"
    DATA_SOURCE_CLASS = "DataSourceClass"
    HTTP_API = "HttpApi"
    HELPER = "Helper"
    DIALOG = "CustomDialog"
    GLOBAL_STATE = "GlobalState"
    PREFERENCES = "Preferences"
    BACKUP_ABILITY = "BackupAbility"


# ═══════════════════════════════════════════════════════════════════════
# Platform-specific edge types
# ═══════════════════════════════════════════════════════════════════════

class PlatformEdgeType(str, Enum):
    CONTAINS = "CONTAINS"
    CALLS = "CALLS"
    EXTENDS = "EXTENDS"
    IMPLEMENTS = "IMPLEMENTS"
    OBSERVES = "OBSERVES"
    BINDS = "BINDS"
    STARTS = "STARTS"
    REGISTERS = "REGISTERS"
    QUERIES = "QUERIES"


# ═══════════════════════════════════════════════════════════════════════
# Mapping rules
# ═══════════════════════════════════════════════════════════════════════

# Default mapping from Android node types to PASG node types
ANDROID_TO_PASG: dict[AndroidNodeType, PasgNodeType] = {
    AndroidNodeType.ACTIVITY: PasgNodeType.SCREEN,
    AndroidNodeType.FRAGMENT: PasgNodeType.SCREEN,
    AndroidNodeType.VIEW_MODEL: PasgNodeType.STATE_CONTAINER,
    AndroidNodeType.SERVICE: PasgNodeType.BACKGROUND_TASK,
    AndroidNodeType.JOB_SERVICE: PasgNodeType.BACKGROUND_TASK,
    AndroidNodeType.BROADCAST_RECEIVER: PasgNodeType.EVENT_HANDLER,
    AndroidNodeType.APP_WIDGET: PasgNodeType.SCREEN,
    AndroidNodeType.ROOM_DATABASE: PasgNodeType.GATEWAY,
    AndroidNodeType.ROOM_DAO: PasgNodeType.GATEWAY,
    AndroidNodeType.RETROFIT_API: PasgNodeType.GATEWAY,
    AndroidNodeType.ADAPTER: PasgNodeType.TRANSFORMER,
    AndroidNodeType.DATA_CLASS: PasgNodeType.DATA_SOURCE,
    AndroidNodeType.ROOM_ENTITY: PasgNodeType.DATA_SOURCE,
    AndroidNodeType.HELPER: PasgNodeType.TRANSFORMER,
    AndroidNodeType.CUSTOM_VIEW: PasgNodeType.SCREEN,
    AndroidNodeType.APPLICATION: PasgNodeType.STATE_CONTAINER,
    AndroidNodeType.SHARED_PREFS: PasgNodeType.STATE_CONTAINER,
}

# Default mapping from HarmonyOS node types to PASG node types
HARMONY_TO_PASG: dict[HarmonyNodeType, PasgNodeType] = {
    HarmonyNodeType.ENTRY_PAGE: PasgNodeType.SCREEN,
    HarmonyNodeType.COMPONENT: PasgNodeType.SCREEN,
    HarmonyNodeType.VIEW_MODEL: PasgNodeType.STATE_CONTAINER,
    HarmonyNodeType.SERVICE_EXT: PasgNodeType.BACKGROUND_TASK,
    HarmonyNodeType.RDB_STORE: PasgNodeType.GATEWAY,
    HarmonyNodeType.DAO: PasgNodeType.GATEWAY,
    HarmonyNodeType.HTTP_API: PasgNodeType.GATEWAY,
    HarmonyNodeType.DATA_SOURCE_CLASS: PasgNodeType.TRANSFORMER,
    HarmonyNodeType.HELPER: PasgNodeType.TRANSFORMER,
    HarmonyNodeType.DIALOG: PasgNodeType.SCREEN,
    HarmonyNodeType.ENTITY: PasgNodeType.DATA_SOURCE,
    HarmonyNodeType.GLOBAL_STATE: PasgNodeType.STATE_CONTAINER,
    HarmonyNodeType.PREFERENCES: PasgNodeType.STATE_CONTAINER,
    HarmonyNodeType.BACKUP_ABILITY: PasgNodeType.BACKGROUND_TASK,
}


# ═══════════════════════════════════════════════════════════════════════
# PASG node and edge data classes
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class PasgNode:
    id: str
    type: PasgNodeType
    name: str
    purpose: str = ""
    platform: str = ""                    # "android" or "harmony"
    original_type: str = ""               # original platform-specific type
    original_file: str = ""
    original_line: int = 0
    properties: dict = field(default_factory=dict)
    llm_inferred: bool = False            # was this mapping LLM-assisted?

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type.value,
            "name": self.name,
            "purpose": self.purpose,
            "platform": self.platform,
            "original_type": self.original_type,
            "original_file": self.original_file,
            "original_line": self.original_line,
            "properties": self.properties,
            "llm_inferred": self.llm_inferred,
        }


@dataclass
class PasgEdge:
    source_id: str
    target_id: str
    type: PasgEdgeType
    platform: str = ""
    properties: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "source": self.source_id,
            "target": self.target_id,
            "type": self.type.value,
            "platform": self.platform,
            "properties": self.properties,
        }


@dataclass
class PasgGraph:
    nodes: list[PasgNode] = field(default_factory=list)
    edges: list[PasgEdge] = field(default_factory=list)
    platform: str = ""
    metadata: dict = field(default_factory=dict)

    def node_count(self) -> int:
        return len(self.nodes)

    def edge_count(self) -> int:
        return len(self.edges)

    def nodes_by_type(self, ntype: PasgNodeType) -> list[PasgNode]:
        return [n for n in self.nodes if n.type == ntype]

    def get_node(self, node_id: str) -> Optional[PasgNode]:
        for n in self.nodes:
            if n.id == node_id:
                return n
        return None

    def out_edges(self, node_id: str) -> list[PasgEdge]:
        return [e for e in self.edges if e.source_id == node_id]

    def to_dict(self) -> dict:
        return {
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "platform": self.platform,
            "metadata": self.metadata,
        }


# ═══════════════════════════════════════════════════════════════════════
# Platform-specific graph data class
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class PlatformNode:
    id: str
    type: str                             # platform-specific type string
    name: str
    kind: str = ""                        # sub-type
    file_path: str = ""
    start_line: int = 0
    end_line: int = 0
    language: str = ""
    properties: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "name": self.name,
            "kind": self.kind,
            "file_path": self.file_path,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "language": self.language,
            "properties": self.properties,
        }


@dataclass
class PlatformEdge:
    source_id: str
    target_id: str
    type: str                              # edge type string
    kind: str = ""
    properties: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "source": self.source_id,
            "target": self.target_id,
            "type": self.type,
            "kind": self.kind,
            "properties": self.properties,
        }


@dataclass
class PlatformGraph:
    nodes: list[PlatformNode] = field(default_factory=list)
    edges: list[PlatformEdge] = field(default_factory=list)
    platform: str = ""
    metadata: dict = field(default_factory=dict)

    def node_count(self) -> int:
        return len(self.nodes)

    def edge_count(self) -> int:
        return len(self.edges)

    def get_node(self, node_id: str) -> Optional[PlatformNode]:
        for n in self.nodes:
            if n.id == node_id:
                return n
        return None

    def nodes_by_type(self, ntype: str) -> list[PlatformNode]:
        return [n for n in self.nodes if n.type == ntype]

    def out_edges(self, node_id: str) -> list[PlatformEdge]:
        return [e for e in self.edges if e.source_id == node_id]

    def in_edges(self, node_id: str) -> list[PlatformEdge]:
        return [e for e in self.edges if e.target_id == node_id]

    def to_dict(self) -> dict:
        return {
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "platform": self.platform,
            "metadata": self.metadata,
        }
