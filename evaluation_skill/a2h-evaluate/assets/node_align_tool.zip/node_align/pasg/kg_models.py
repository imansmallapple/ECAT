"""Knowledge graph data models — inlined from arkts-knowledge-graph.

Entity, Relation, Graph are the core data structures used across the PASG pipeline.
Inlined to eliminate the arkts-knowledge-graph dependency.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from typing import Optional


# ═══════════════════════════════════════════════════════════════════════
# Entity types
# ═══════════════════════════════════════════════════════════════════════

class EntityType(str, Enum):
    FILE = "file"
    CLASS = "class"
    FUNCTION = "function"
    VARIABLE = "variable"
    DECORATOR = "decorator"
    IMPORT = "import"
    ENUM = "enum"
    TYPE = "type"
    NAMESPACE = "namespace"


class RelationType(str, Enum):
    CONTAINS = "CONTAINS"
    CALLS = "CALLS"
    REFERENCES = "REFERENCES"
    INHERITS_FROM = "INHERITS_FROM"
    USES_DECORATOR = "USES_DECORATOR"
    EXPORTS = "EXPORTS"


class RelationKind(str, Enum):
    CALLS = "calls"
    EXTENDS = "extends"
    IMPLEMENTS = "implements"
    DECORATOR = "decorator"


@dataclass
class SourceLocation:
    file_path: str
    start_line: int
    end_line: int
    start_column: int = 1
    end_column: int = 1

    def to_dict(self) -> dict:
        return {
            "file": self.file_path,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "start_column": self.start_column,
            "end_column": self.end_column,
        }


@dataclass
class Entity:
    id: str
    type: EntityType
    name: str
    kind: Optional[str] = None
    location: Optional[SourceLocation] = None
    language: str = ""
    properties: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = {"id": self.id, "type": self.type.value, "name": self.name,
             "language": self.language, "properties": self.properties}
        if self.kind: d["kind"] = self.kind
        if self.location: d["location"] = self.location.to_dict()
        return d


@dataclass
class Relation:
    source_id: str
    target_id: str
    type: RelationType
    kind: Optional[str] = None
    properties: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = {"source": self.source_id, "target": self.target_id,
             "type": self.type.value, "properties": self.properties}
        if self.kind: d["kind"] = self.kind
        return d


# ═══════════════════════════════════════════════════════════════════════
# In-memory graph
# ═══════════════════════════════════════════════════════════════════════

class Graph:
    """Directed graph holding extracted entities and their relationships."""

    def __init__(self):
        self._entities: dict[str, Entity] = {}
        self._relations: list[Relation] = []
        self._adj_out: dict[str, list[Relation]] = defaultdict(list)
        self._adj_in: dict[str, list[Relation]] = defaultdict(list)
        self._by_type: dict[EntityType, list[str]] = defaultdict(list)

    def add_entity(self, entity: Entity) -> None:
        if entity.id in self._entities: return
        self._entities[entity.id] = entity
        self._by_type[entity.type].append(entity.id)

    def add_relation(self, rel: Relation) -> None:
        if rel.source_id not in self._entities or rel.target_id not in self._entities: return
        self._relations.append(rel)
        self._adj_out[rel.source_id].append(rel)
        self._adj_in[rel.target_id].append(rel)

    @property
    def entities(self) -> dict[str, Entity]: return self._entities

    @property
    def relations(self) -> list[Relation]: return self._relations

    def get_entity(self, entity_id: str) -> Optional[Entity]:
        return self._entities.get(entity_id)

    def entity_count(self) -> int: return len(self._entities)

    def relation_count(self) -> int: return len(self._relations)

    def entities_by_type(self, etype: EntityType) -> list[Entity]:
        return [self._entities[eid] for eid in self._by_type.get(etype, [])]

    def entities_by_kind(self, etype: EntityType, kind: str) -> list[Entity]:
        return [e for e in self.entities_by_type(etype) if e.kind == kind]

    def callers(self, entity_id: str) -> list[Entity]:
        return [self._entities[r.source_id] for r in self._adj_in.get(entity_id, []) if r.type == RelationType.CALLS]

    def callees(self, entity_id: str) -> list[Entity]:
        return [self._entities[r.target_id] for r in self._adj_out.get(entity_id, []) if r.type == RelationType.CALLS]

    def to_dict(self) -> dict:
        return {"entities": [e.to_dict() for e in self._entities.values()],
                "relations": [r.to_dict() for r in self._relations]}
