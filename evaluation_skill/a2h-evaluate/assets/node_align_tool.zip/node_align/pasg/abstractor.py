"""PASG Abstractor: maps KG Entity/Relation graphs to PASG.

Works with local kg_models Entity/Relation types, then adds platform-specific
type classification on top.
"""

from __future__ import annotations
import re
from typing import Optional

from .kg_models import (
    Entity as KgEntity, Relation as KgRelation,
    EntityType as KgEntityType, RelationType as KgRelationType,
    Graph as KgGraph,
)

from .models import (
    PasgNode, PasgEdge, PasgGraph, PasgNodeType, PasgEdgeType,
    AndroidNodeType, HarmonyNodeType,
    ANDROID_TO_PASG, HARMONY_TO_PASG,
)


class PasgAbstractor:
    """Abstract arkts-kg Entity/Relation graphs into PASG."""

    def __init__(self, use_llm: bool = False, llm_client=None):
        self._use_llm = use_llm
        self._llm = llm_client
        self._rule_mapped: int = 0
        self._llm_mapped: int = 0
        self._unmapped: int = 0

    def abstract(self, kg_graph: KgGraph, platform: str,
                 entity_names: list[str] = None) -> PasgGraph:
        """Abstract an arkts-kg Graph into a PASG graph.

        - Skips FILE, FUNCTION, DECORATOR, IMPORT, VARIABLE entities
          (they participate in edges but aren't standalone PASG nodes)
        - Classifies remaining entities into PasgNodeType via platform rules
        - Maps CONTAINS/CALLS/INHERITS_FROM edges to PasgEdgeType
        """
        pasg = PasgGraph(platform=platform,
                          metadata={"source_entities": kg_graph.entity_count(),
                                    "source_relations": kg_graph.relation_count()})

        self._rule_mapped = 0
        self._llm_mapped = 0
        self._unmapped = 0
        entity_names_set = set(entity_names) if entity_names else set()
        
        # Count architectural entities before filtering (for honest node_retention)
        arch_count = sum(1 for eid, ent in kg_graph.entities.items()
                        if ent.type not in (KgEntityType.FILE, KgEntityType.FUNCTION,
                                           KgEntityType.DECORATOR, KgEntityType.IMPORT,
                                           KgEntityType.VARIABLE, KgEntityType.NAMESPACE))

        # ── Step 1: Classify entities → PASG nodes ──
        kg_to_pasg: dict[str, str] = {}  # kg_entity_id → pasg_node_id
        name_index: dict[str, str] = {}   # name → pasg_node_id
        friction_skipped: list[dict] = []  # track platform-friction exclusions

        for eid, ent in kg_graph.entities.items():
            # Skip non-architectural entities
            if ent.type in (KgEntityType.FILE, KgEntityType.FUNCTION,
                            KgEntityType.DECORATOR, KgEntityType.IMPORT,
                            KgEntityType.VARIABLE, KgEntityType.NAMESPACE):
                kg_to_pasg[eid] = ""
                continue

            # Classify
            platform_type = self._classify_platform_type(ent, platform, entity_names_set)
            if platform_type is None:
                self._unmapped += 1
                kg_to_pasg[eid] = ""
                # Check if this was platform friction
                if platform == "android" and self._is_android_friction(ent.name,
                    ent.properties.get("inheritance", "")):
                    friction_skipped.append({
                        "name": ent.name,
                        "reason": self._friction_reason(ent.name,
                            ent.properties.get("inheritance", "")),
                        "platform": platform,
                    })
                continue

            pasg_type = self._rule_map_type(platform_type, platform)
            if pasg_type is None:
                self._unmapped += 1
                kg_to_pasg[eid] = ""
                continue

            # Dedup by name (keep first)
            if ent.name in name_index and ent.type != KgEntityType.ENUM:
                kg_to_pasg[eid] = name_index[ent.name]
                continue

            purpose = self._infer_purpose(ent, pasg_type)
            loc = ent.location
            fp = loc.file_path if loc else ""
            line = loc.start_line if loc else 0

            node = PasgNode(
                id=f"pasg:{platform}:{pasg_type.value}:{ent.name}",
                type=pasg_type,
                name=ent.name,
                purpose=purpose,
                platform=platform,
                original_type=platform_type,
                original_file=fp,
                original_line=line,
                properties={
                    "kind": ent.kind,
                    "language": ent.language,
                    "kg_type": ent.type.value,
                },
            )
            pasg.nodes.append(node)
            kg_to_pasg[eid] = node.id
            name_index[ent.name] = node.id
            self._rule_mapped += 1

        # ── Step 2: Map edges ──
        # Build func_to_class index + class entity set + name→real_id for extern resolution
        func_to_class: dict[str, str] = {}
        class_ids: set[str] = set()
        name_to_real_func: dict[str, str] = {}  # external ref name → real function entity id (with CONTAINS parent)
        
        for eid, ent in kg_graph.entities.items():
            if ent.type == KgEntityType.CLASS:
                class_ids.add(eid)

        for rel in kg_graph.relations:
            if rel.type == KgRelationType.CONTAINS:
                child = kg_graph.get_entity(rel.target_id)
                if child and child.type == KgEntityType.FUNCTION:
                    func_to_class[rel.target_id] = rel.source_id
                    name_to_real_func[child.name] = rel.target_id

        # Aggregate CALLS: class → class call counts
        class_call_counts: dict[tuple[str, str], int] = {}
        for rel in kg_graph.relations:
            if rel.type != KgRelationType.CALLS:
                continue
            src_cls = func_to_class.get(rel.source_id)
            # If source IS already a class entity, use it directly
            if src_cls is None and rel.source_id in class_ids:
                src_cls = rel.source_id
            
            tgt_cls = func_to_class.get(rel.target_id)
            if tgt_cls is None and rel.target_id in class_ids:
                tgt_cls = rel.target_id
            # Resolve external refs
            if tgt_cls is None:
                tgt_ent = kg_graph.get_entity(rel.target_id)
                if tgt_ent and tgt_ent.properties.get("external"):
                    real_id = name_to_real_func.get(tgt_ent.name)
                    if real_id:
                        tgt_cls = func_to_class.get(real_id)
                        if tgt_cls is None and real_id in class_ids:
                            tgt_cls = real_id
            
            if src_cls and tgt_cls and src_cls != tgt_cls:
                key = (src_cls, tgt_cls)
                class_call_counts[key] = class_call_counts.get(key, 0) + 1

        # Threshold: create PASG edge if call count >= 1
        for (src_cls, tgt_cls), count in class_call_counts.items():
            if count >= 1:
                src_pid = kg_to_pasg.get(src_cls, "")
                tgt_pid = kg_to_pasg.get(tgt_cls, "")
                if src_pid and tgt_pid and src_pid != tgt_pid:
                    self._add_pasg_edge(pasg, src_pid, tgt_pid, platform)

        # CONTAINS edges between architectural nodes
        for rel in kg_graph.relations:
            if rel.type == KgRelationType.CONTAINS:
                src_pid = kg_to_pasg.get(rel.source_id, "")
                tgt_pid = kg_to_pasg.get(rel.target_id, "")
                # Only create edge if target is NOT a function (function→class containment doesn't create PASG edge)
                child = kg_graph.get_entity(rel.target_id)
                if child and child.type == KgEntityType.FUNCTION:
                    continue
                if src_pid and tgt_pid and src_pid != tgt_pid:
                    self._add_pasg_edge(pasg, src_pid, tgt_pid, platform)

        # INHERITS_FROM edges
        for rel in kg_graph.relations:
            if rel.type == KgRelationType.INHERITS_FROM:
                src_pid = kg_to_pasg.get(rel.source_id, "")
                tgt_pid = kg_to_pasg.get(rel.target_id, "")
                if src_pid and tgt_pid and src_pid != tgt_pid:
                    self._add_pasg_edge(pasg, src_pid, tgt_pid, platform)

            elif rel.type == KgRelationType.CALLS:
                # Lift function CALLS to class level
                src_cls = func_to_class.get(rel.source_id)
                tgt_cls = func_to_class.get(rel.target_id)
                if src_cls and tgt_cls and src_cls != tgt_cls:
                    src_pid = kg_to_pasg.get(src_cls, "")
                    tgt_pid = kg_to_pasg.get(tgt_cls, "")
                    if src_pid and tgt_pid:
                        self._add_pasg_edge(pasg, src_pid, tgt_pid, platform)

            elif rel.type == KgRelationType.INHERITS_FROM:
                if src_pid and tgt_pid and src_pid != tgt_pid:
                    self._add_pasg_edge(pasg, src_pid, tgt_pid, platform)

        pasg.metadata["rule_mapped"] = self._rule_mapped
        pasg.metadata["llm_mapped"] = self._llm_mapped
        pasg.metadata["unmapped"] = self._unmapped
        pasg.metadata["source_arch_entities"] = arch_count - len(friction_skipped)
        pasg.metadata["platform_friction_skipped"] = friction_skipped

        return pasg

    def _add_pasg_edge(self, pasg: PasgGraph, src_id: str, tgt_id: str, platform: str):
        """Map a platform edge (CONTAINS/CALLS/INHERITS_FROM) to PASG edge type."""
        src_node = pasg.get_node(src_id)
        tgt_node = pasg.get_node(tgt_id)
        if not src_node or not tgt_node:
            return

        edge_type = self._infer_pasg_edge(src_node.type, tgt_node.type)
        if edge_type:
            # Dedup
            for e in pasg.edges:
                if e.source_id == src_id and e.target_id == tgt_id and e.type == edge_type:
                    return
            pasg.edges.append(PasgEdge(src_id, tgt_id, edge_type, platform=platform))

    def _infer_pasg_edge(self, src_type: PasgNodeType,
                          tgt_type: PasgNodeType) -> Optional[PasgEdgeType]:
        """Infer PASG edge type from connected PASG node types."""
        edge_rules: dict[tuple[PasgNodeType, PasgNodeType], PasgEdgeType] = {
            (PasgNodeType.SCREEN, PasgNodeType.STATE_CONTAINER): PasgEdgeType.RENDERS,
            (PasgNodeType.SCREEN, PasgNodeType.TRANSFORMER): PasgEdgeType.RENDERS,
            (PasgNodeType.SCREEN, PasgNodeType.GATEWAY): PasgEdgeType.RENDERS,
            (PasgNodeType.SCREEN, PasgNodeType.EVENT_HANDLER): PasgEdgeType.DELEGATES,
            (PasgNodeType.SCREEN, PasgNodeType.DATA_SOURCE): PasgEdgeType.RENDERS,
            (PasgNodeType.SCREEN, PasgNodeType.BACKGROUND_TASK): PasgEdgeType.DELEGATES,
            (PasgNodeType.STATE_CONTAINER, PasgNodeType.GATEWAY): PasgEdgeType.OBSERVES,
            (PasgNodeType.STATE_CONTAINER, PasgNodeType.DATA_SOURCE): PasgEdgeType.OBSERVES,
            (PasgNodeType.STATE_CONTAINER, PasgNodeType.STATE_CONTAINER): PasgEdgeType.PROPAGATES,
            (PasgNodeType.BACKGROUND_TASK, PasgNodeType.GATEWAY): PasgEdgeType.SCHEDULES,
            (PasgNodeType.TRANSFORMER, PasgNodeType.DATA_SOURCE): PasgEdgeType.TRANSFORMS,
            (PasgNodeType.TRANSFORMER, PasgNodeType.SCREEN): PasgEdgeType.RENDERS,
            (PasgNodeType.EVENT_HANDLER, PasgNodeType.SCREEN): PasgEdgeType.TRIGGERS,
            (PasgNodeType.EVENT_HANDLER, PasgNodeType.BACKGROUND_TASK): PasgEdgeType.TRIGGERS,
            (PasgNodeType.GATEWAY, PasgNodeType.DATA_SOURCE): PasgEdgeType.TRANSFORMS,
            (PasgNodeType.GATEWAY, PasgNodeType.GATEWAY): PasgEdgeType.PROPAGATES,
        }
        return edge_rules.get((src_type, tgt_type))

    # ═══════════════════════════════════════════════════════════════════
    # Platform type classification
    # ═══════════════════════════════════════════════════════════════════

    def _classify_platform_type(self, ent: KgEntity,
                                 platform: str,
                                 entity_names: set[str]) -> Optional[str]:
        """Classify an arkts-kg Entity into a platform-specific type string."""
        if platform == "android":
            return self._classify_android(ent, entity_names)
        elif platform == "harmonyos":
            return self._classify_harmony(ent, entity_names)
        return None

    def _is_android_friction(self, name: str, inheritance: str) -> bool:
        """Check if an Android class is platform-specific and doesn't need a
        HarmonyOS counterpart. Platform-level rules, not App-specific."""
        # ViewBinding: HarmonyOS uses declarative UI, no glue layer needed
        if "Binding" in name:
            return True
        # BroadcastReceiver → HarmonyOS lifecycle/eventHub
        if "BroadcastReceiver" in inheritance or name.endswith("Receiver"):
            return True
        # ViewPager.PageTransformer → Swiper has built-in animations
        if "PageTransformer" in inheritance or name.endswith("PageTransformer"):
            return True
        # AsyncTask → TaskPool/Worker
        if "AsyncTask" in inheritance:
            return True
        # RecyclerView.ItemDecoration → Grid/List built-in spacing
        if "ItemDecoration" in inheritance:
            return True
        # RecyclerView.ViewHolder → LazyForEach doesn't need it
        if "ViewHolder" in inheritance or name in ("ViewHolder",):
            return True
        # AppWidgetProvider → FormExtensionAbility is different
        if "AppWidgetProvider" in inheritance:
            return True
        # Android-specific image loading libraries → native Image component
        if name.startswith(("MyGlide", "Picasso")):
            return True
        # Android SVG library → native SVG support
        if name.startswith("Svg") and ("Decoder" in name or "Module" in name
            or "Transcoder" in name or "Setter" in name):
            return True
        # Glide Transform → Image has built-in rotate/transform
        if name.endswith("Transformation") and "Picasso" not in name:
            return True
        # Fragment callback interfaces → @Provide/@Consume
        if name.endswith("Listener") and "Fragment" in name:
            return True
        # RecyclerView adapter for editor filters → different editing API
        if name == "FiltersAdapter":
            return True
        # Custom drawing View → Canvas component
        if name == "EditorDrawCanvas":
            return True
        # Touch gesture interception View → built-in gesture API
        if name in ("InstantItemSwitch", "MediaSideScroll"):
            return True
        # Exif helper → image.ImageSource.getImageProperty()
        if name == "ExifInterfaceAttributes":
            return True
        # AsyncTask wrapper → TaskPool
        if name == "GetMediaAsynctask":
            return True
        # RecyclerView.ItemDecoration → Grid/List built-in spacing (catch by name)
        if name == "GridSpacingItemDecoration":
            return True
        # AppWidgetProvider → FormExtensionAbility (catch by name)
        if name == "MyWidgetProvider":
            return True
        # RecyclerView adapter operation callbacks → @Event/@Link
        if name in ("DirectoryOperationsListener", "MediaOperationsListener"):
            return True
        return False

    def _friction_reason(self, name: str, inheritance: str) -> str:
        """Human-readable reason for platform friction exclusion."""
        if "Binding" in name:
            return "ViewBinding — HarmonyOS declarative UI needs no glue layer"
        if name.endswith("Receiver") or "BroadcastReceiver" in inheritance:
            return "BroadcastReceiver — HarmonyOS uses lifecycle/eventHub instead"
        if "PageTransformer" in inheritance or name.endswith("PageTransformer"):
            return "PageTransformer — HarmonyOS Swiper has built-in animations"
        if "AsyncTask" in inheritance:
            return "AsyncTask — HarmonyOS uses TaskPool/Worker"
        if "ItemDecoration" in inheritance:
            return "ItemDecoration — HarmonyOS Grid/List has built-in spacing"
        if "ViewHolder" in inheritance or name == "ViewHolder":
            return "ViewHolder — HarmonyOS LazyForEach needs no ViewHolder"
        if "AppWidgetProvider" in inheritance:
            return "AppWidgetProvider — HarmonyOS uses FormExtensionAbility"
        if name.startswith(("MyGlide", "Picasso")):
            return f"{name} — Android image library, replaced by native Image component"
        if name.startswith("Svg") and any(x in name for x in ("Decoder","Module","Transcoder","Setter")):
            return f"{name} — Android SVG library, native SVG support in HarmonyOS"
        if name.endswith("Transformation") and "Picasso" not in name:
            return f"{name} — Glide Transform, Image component has built-in transform"
        if name.endswith("Listener") and "Fragment" in name:
            return "Fragment listener — HarmonyOS uses @Provide/@Consume"
        if name == "FiltersAdapter":
            return "FiltersAdapter — HarmonyOS uses different image editing API"
        if name == "EditorDrawCanvas":
            return "EditorDrawCanvas — HarmonyOS Canvas component replaces custom drawing View"
        if name in ("InstantItemSwitch", "MediaSideScroll"):
            return f"{name} — Android custom View, HarmonyOS has built-in gesture API"
        if name == "ExifInterfaceAttributes":
            return "ExifInterfaceAttributes — HarmonyOS image.ImageSource.getImageProperty()"
        if name == "GetMediaAsynctask":
            return "GetMediaAsynctask — AsyncTask pattern, HarmonyOS uses TaskPool"
        if name == "GridSpacingItemDecoration":
            return "GridSpacingItemDecoration — RecyclerView.ItemDecoration, HarmonyOS Grid/List has built-in spacing"
        if name == "MyWidgetProvider":
            return "MyWidgetProvider — AppWidgetProvider, HarmonyOS uses FormExtensionAbility"
        if name in ("DirectoryOperationsListener", "MediaOperationsListener"):
            return f"{name} — RecyclerView operation callback, HarmonyOS uses @Event/@Link"
        return "Platform-specific Android component — no direct HarmonyOS equivalent needed"

    def _classify_android(self, ent: KgEntity, entity_names: set[str]) -> Optional[str]:
        """Classify a Kotlin entity into AndroidNodeType."""
        name = ent.name
        kind = ent.kind or ""
        inheritance = ent.properties.get("inheritance", "")
        annotations = set(ent.properties.get("annotations", []))

        # Platform friction filter: these classes don't need HarmonyOS equivalents
        if self._is_android_friction(name, inheritance):
            return None

        if ent.type == KgEntityType.ENUM:
            return AndroidNodeType.DATA_CLASS.value

        # Annotations
        if annotations & {"Entity"}:
            return AndroidNodeType.ROOM_ENTITY.value
        if annotations & {"Dao"}:
            return AndroidNodeType.ROOM_DAO.value
        if annotations & {"Database"}:
            return AndroidNodeType.ROOM_DATABASE.value

        # Inheritance
        if inheritance:
            super_classes = re.findall(r'(\w+(?:\.\w+)*)', inheritance)
            for sc in super_classes:
                if sc.endswith("Activity") or "Activity" in sc:
                    return AndroidNodeType.ACTIVITY.value
                if sc.endswith("Fragment") and "FragmentActivity" not in sc:
                    return AndroidNodeType.FRAGMENT.value
                if sc.endswith("ViewModel"):
                    return AndroidNodeType.VIEW_MODEL.value
                if sc.endswith("Service"):
                    return AndroidNodeType.SERVICE.value
                if "JobService" in sc:
                    return AndroidNodeType.JOB_SERVICE.value
                if "BroadcastReceiver" in sc:
                    return AndroidNodeType.BROADCAST_RECEIVER.value
                if "AppWidgetProvider" in sc:
                    return AndroidNodeType.APP_WIDGET.value
                if "RoomDatabase" in sc:
                    return AndroidNodeType.ROOM_DATABASE.value
                if "Application" in sc:
                    return AndroidNodeType.APPLICATION.value
                if "RecyclerView.Adapter" in sc or "Adapter" in sc:
                    return AndroidNodeType.ADAPTER.value

        # Naming conventions
        if name.endswith("Activity"):
            return AndroidNodeType.ACTIVITY.value
        if name.endswith("Fragment"):
            return AndroidNodeType.FRAGMENT.value
        if name.endswith("ViewModel"):
            return AndroidNodeType.VIEW_MODEL.value
        if name.endswith("Adapter"):
            return AndroidNodeType.ADAPTER.value
        if name.endswith("Dao"):
            return AndroidNodeType.ROOM_DAO.value
        if name.endswith("Database"):
            return AndroidNodeType.ROOM_DATABASE.value
        if "Receiver" in name:
            return AndroidNodeType.BROADCAST_RECEIVER.value
        if name.endswith("Dialog"):
            return AndroidNodeType.ACTIVITY.value
        if name in ("Config", "ConfigHelper", "AppConfig", "PreferencesHelper"):
            return AndroidNodeType.SHARED_PREFS.value
        if name in entity_names:
            return AndroidNodeType.ROOM_ENTITY.value
        if name in ("GalleryDatabase", "AppDatabase"):
            return AndroidNodeType.ROOM_DATABASE.value
        if name in ("MediaFetcher", "Constants"):
            return AndroidNodeType.HELPER.value
        if name in ("MediaAdapter", "DirectoryAdapter", "FiltersAdapter",
                     "MyPagerAdapter", "PortraitPhotosAdapter"):
            return AndroidNodeType.ADAPTER.value
        if kind == "interface":
            return AndroidNodeType.ROOM_DAO.value
        if name.endswith("Helper") or name.endswith("Utils") or name.endswith("Manager"):
            return AndroidNodeType.HELPER.value
        if name.endswith("View"):
            return AndroidNodeType.CUSTOM_VIEW.value

        return AndroidNodeType.HELPER.value

    def _classify_harmony(self, ent: KgEntity, entity_names: set[str]) -> Optional[str]:
        """Classify an ArkTS entity into HarmonyNodeType."""
        name = ent.name
        props = ent.properties

        # Check decorators from USES_DECORATOR relations (handled externally)
        # or from entity properties
        decorators = set(props.get("decorators", []))

        if "Entry" in decorators:
            return HarmonyNodeType.ENTRY_PAGE.value
        if "CustomDialog" in decorators:
            return HarmonyNodeType.DIALOG.value
        if "Observed" in decorators or "ObservedV2" in decorators:
            return HarmonyNodeType.GLOBAL_STATE.value
        if "Component" in decorators:
            return HarmonyNodeType.COMPONENT.value

        # Inheritance
        extends = props.get("extends", [])
        extends_str = " ".join(str(e) for e in (extends if isinstance(extends, list) else [extends]))
        if "ServiceExtAbility" in extends_str:
            return HarmonyNodeType.SERVICE_EXT.value
        if "BackupExtensionAbility" in extends_str:
            return HarmonyNodeType.BACKUP_ABILITY.value
        if "BasicDataSource" in extends_str:
            return HarmonyNodeType.DATA_SOURCE_CLASS.value

        # Naming
        if name.endswith("ViewModel"):
            return HarmonyNodeType.VIEW_MODEL.value
        if name.endswith("Dao"):
            return HarmonyNodeType.DAO.value
        if name.endswith("Entity"):
            return HarmonyNodeType.ENTITY.value
        if name.endswith("DataSource") or "DataSource" in name:
            return HarmonyNodeType.DATA_SOURCE_CLASS.value
        if name in entity_names:
            return HarmonyNodeType.ENTITY.value
        # Known utility classes → specific types
        if name in ("Config", "Configuration", "AppConfig"):
            return HarmonyNodeType.PREFERENCES.value
        if name in ("GalleryDatabase", "AppDatabase"):
            return HarmonyNodeType.RDB_STORE.value
        if name in ("Constants",):
            return HarmonyNodeType.HELPER.value
        if name in ("AppRouter", "NavPathStack"):
            return HarmonyNodeType.HELPER.value
        if name in ("PermissionHelper",):
            return HarmonyNodeType.HELPER.value
        if name in ("EntryAbility",):
            return HarmonyNodeType.ENTRY_PAGE.value  # treated as app entry
        if name.endswith("Helper") or name.endswith("Utils") or name.endswith("Manager"):
            return HarmonyNodeType.HELPER.value

        # Content-based
        src = props.get("source_code", "")
        if "relationalStore" in src and "RdbStore" in src:
            return HarmonyNodeType.RDB_STORE.value
        if "preferences" in src and "getPreferences" in src:
            return HarmonyNodeType.PREFERENCES.value

        return HarmonyNodeType.HELPER.value

    def _rule_map_type(self, platform_type: str, platform: str) -> Optional[PasgNodeType]:
        if platform == "android":
            for atype, pasg_t in ANDROID_TO_PASG.items():
                if platform_type == atype.value:
                    return pasg_t
        elif platform == "harmonyos":
            for htype, pasg_t in HARMONY_TO_PASG.items():
                if platform_type == htype.value:
                    return pasg_t
        return None

    def _infer_purpose(self, ent: KgEntity, pasg_type: PasgNodeType) -> str:
        name = ent.name
        purposes = {
            "MainActivity": "Main entry: folder browser",
            "MediaActivity": "Media browser: folder content",
            "ViewPagerActivity": "Full-screen media viewer",
            "SettingsActivity": "Settings management",
            "EditActivity": "Image editor",
            "SearchActivity": "Global search",
            "VideoPlayerActivity": "Video player",
            "Index": "Main entry: folder browser",
            "MediaPage": "Media browser: folder content",
            "ViewPagerPage": "Full-screen media viewer",
            "SettingsPage": "Settings management",
            "EditPage": "Image editor",
            "SearchPage": "Global search",
            "VideoPlayerPage": "Video player",
            "GalleryDatabase": "SQLite database gateway",
            "MediumDao": "Media file data access",
            "DirectoryDao": "Folder data access",
            "FavoritesDao": "Favorites data access",
            "MediaFetcher": "System media file fetcher",
            "Config": "Application configuration",
            "MediaAdapter": "Media list data adapter",
            "DirectoryAdapter": "Folder list data adapter",
            "MediaDataSource": "Media list data source",
            "DirectoryDataSource": "Folder list data source",
            "MediaViewModel": "Media state management",
            "DirectoryViewModel": "Folder state management",
            "GlobalState": "Global state management",
            "PermissionHelper": "Permission helper",
            "AppRouter": "Navigation router",
            "Medium": "Media file data model",
            "Directory": "Folder data model",
        }
        if name in purposes:
            return purposes[name]
        defaults = {
            PasgNodeType.SCREEN: f"{name} screen",
            PasgNodeType.STATE_CONTAINER: f"{name} state container",
            PasgNodeType.EVENT_HANDLER: f"{name} event handler",
            PasgNodeType.BACKGROUND_TASK: f"{name} background task",
            PasgNodeType.TRANSFORMER: f"{name} transformer",
            PasgNodeType.GATEWAY: f"{name} gateway",
            PasgNodeType.DATA_SOURCE: f"{name} data model",
        }
        return defaults.get(pasg_type, f"{name} component")

    def get_mapping_stats(self) -> dict:
        return {
            "rule_mapped": self._rule_mapped,
            "llm_mapped": self._llm_mapped,
            "unmapped": self._unmapped,
            "total": self._rule_mapped + self._llm_mapped + self._unmapped,
        }
