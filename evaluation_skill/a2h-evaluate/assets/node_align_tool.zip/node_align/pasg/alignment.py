"""PASG Graph Alignment and Equivalence Scoring.

Three-step algorithm:
  1. Node attribute-based initial alignment (name + purpose similarity)
  2. Structure-based refined alignment (neighbor consistency)
  3. Equivalence scoring (node/edge/path retention)
"""

from __future__ import annotations
import re
from collections import defaultdict
from typing import Optional

from .models import (
    PasgNode, PasgEdge, PasgGraph, PasgNodeType, PasgEdgeType,
)


# ═══════════════════════════════════════════════════════════════════════
# Name similarity helpers
# ═══════════════════════════════════════════════════════════════════════

def _stem_token(word: str) -> str:
    """Lightweight English stemming for cross-platform name matching.

    Strips common suffixes so e.g. 'sorting' → 'sort', 'grouping' → 'group',
    allowing the token Jaccard to match across gerund/root pairs.
    """
    w = word.lower()
    if len(w) <= 4:
        return w
    if w.endswith("ing") and len(w) > 5:
        stem = w[:-3]
        # Handle doubled consonant: "running" → "run"
        if len(stem) >= 3 and stem[-1] == stem[-2]:
            stem = stem[:-1]
        return stem
    return w


def _tokenize_name(name: str) -> set[str]:
    """Split camelCase/PascalCase name into tokens, including stemmed forms."""
    tokens = set()
    # Split on camelCase boundaries
    words = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]+|\d+', name)
    for w in words:
        wl = w.lower()
        if len(wl) > 1:
            tokens.add(wl)
            # Also add stemmed form for cross-platform matching
            stem = _stem_token(wl)
            if stem != wl:
                tokens.add(stem)
    return tokens


# Known name mappings between Android and HarmonyOS
_NAME_SYNONYMS: dict[str, set[str]] = {
    "activity": {"page", "index", "activity"},
    "fragment": {"component", "view", "fragment"},
    "viewpager": {"swiper", "slider", "viewpager", "pager"},
    "adapter": {"datasource", "adapter", "source"},
    "dao": {"dao", "db", "database"},
    "receiver": {"handler", "observer", "subscriber", "receiver"},
    "main": {"index", "main", "home"},
    "media": {"media", "photo", "album", "gallery"},
    "directory": {"album", "directory", "folder"},
    "favorite": {"favorite", "favourite", "star", "bookmark"},
    "recycle": {"trash", "bin", "recycle", "deleted"},
    "search": {"search", "find", "query"},
    "settings": {"setting", "config", "preference", "option"},
    "edit": {"edit", "editor", "modify", "crop"},
    "video": {"video", "player", "movie"},
    "photo": {"photo", "image", "picture"},
    "viewmodel": {"viewmodel", "store", "state", "model"},
    "fetcher": {"fetcher", "loader", "scanner", "fetch"},
}


def _expand_tokens(tokens: set[str]) -> set[str]:
    """Expand tokens with synonyms for cross-platform matching."""
    expanded = set(tokens)
    for token in tokens:
        for key, synonyms in _NAME_SYNONYMS.items():
            if token in synonyms:
                expanded.update(synonyms)
    return expanded


# App-specific mappings (injected by bootstrap config or user)
_APP_MAPPINGS: dict[str, str] = {}


def set_app_mappings(mappings: dict[str, str]):
    """Inject app-specific name mappings from bootstrap or user config."""
    global _APP_MAPPINGS
    _APP_MAPPINGS = dict(mappings)


def _name_similarity(name1: str, name2: str) -> float:
    """Compute cross-platform name similarity with synonym expansion."""
    # Check app-specific mappings first (injected from bootstrap or user config)
    if name1 in _APP_MAPPINGS and _APP_MAPPINGS[name1] == name2:
        return 0.95
    if name2 in _APP_MAPPINGS and _APP_MAPPINGS[name2] == name1:
        return 0.95

    t1 = _tokenize_name(name1)
    t2 = _tokenize_name(name2)

    e1 = _expand_tokens(t1)
    e2 = _expand_tokens(t2)

    # Direct Jaccard
    intersection_direct = len(t1 & t2)
    union_direct = len(t1 | t2)
    direct_sim = intersection_direct / union_direct if union_direct else 0.0

    # Expanded Jaccard
    intersection_exp = len(e1 & e2)
    union_exp = len(e1 | e2)
    expanded_sim = intersection_exp / union_exp if union_exp else 0.0

    # Normalized prefix matching
    prefix_sim = 0.0
    if len(name1) >= 3 and len(name2) >= 3:
        min_len = min(len(name1), len(name2))
        matches = sum(1 for i in range(min_len)
                     if name1[i].lower() == name2[i].lower())
        prefix_sim = matches / min_len

    return max(direct_sim, expanded_sim * 0.8, prefix_sim * 0.5)


# ═══════════════════════════════════════════════════════════════════════
# Main aligner
# ═══════════════════════════════════════════════════════════════════════

class PasgAligner:
    """Align two PASG graphs and compute equivalence scores."""

    def __init__(self,
                 node_similarity_threshold: float = 0.70,
                 node_weight: float = 0.4,
                 edge_weight: float = 0.3,
                 path_weight: float = 0.3,
                 name_mappings: dict[str, str] = None):
        self._theta = node_similarity_threshold      # min sim to pair (single threshold)
        self._w_node = node_weight
        self._w_edge = edge_weight
        self._w_path = path_weight
        if name_mappings:
            set_app_mappings(name_mappings)

    def align(self, pasg_src: PasgGraph, pasg_tgt: PasgGraph,
              verbose: bool = False) -> "AlignmentResult":
        """Align two PASG graphs."""
        # Step 1: Initial alignment by node attributes
        candidate_pairs = self._initial_alignment(pasg_src, pasg_tgt)

        if verbose:
            print(f"  Step 1 (initial): {len(candidate_pairs)} candidate pairs")

        # Step 2: Structural refinement
        aligned_pairs = self._refine_alignment(pasg_src, pasg_tgt, candidate_pairs)

        if verbose:
            print(f"  Step 2 (refined): {len(aligned_pairs)} refined pairs")

        # Step 3: Equivalence scoring
        scores = self._compute_equivalence(pasg_src, pasg_tgt, aligned_pairs)

        if verbose:
            print(f"  Step 3 (scores): node={scores['node_retention']:.3f}, "
                  f"edge={scores['edge_retention']:.3f}, "
                  f"path={scores['path_retention']:.3f}, "
                  f"overall={scores['overall_score']:.3f}")

        return AlignmentResult(
            aligned_pairs=aligned_pairs,
            candidate_pairs=candidate_pairs,
            scores=scores,
            src_graph=pasg_src,
            tgt_graph=pasg_tgt,
        )

    def _initial_alignment(self, g1: PasgGraph, g2: PasgGraph
                           ) -> list[tuple[str, str, float]]:
        """Step 1: Node attribute-based alignment."""
        candidates: list[tuple[str, str, float]] = []

        for n1 in g1.nodes:
            for n2 in g2.nodes:
                name_sim = _name_similarity(n1.name, n2.name)

                # Allow cross-type matching only for very high name similarity (>0.80)
                type_match = (n1.type == n2.type)
                if not type_match and name_sim < 0.80:
                    continue

                # Boost for exact original type matches
                type_bonus = 0.0
                if type_match and n1.original_type == n2.original_type:
                    type_bonus = 0.1

                overall_sim = name_sim + type_bonus

                if overall_sim > self._theta:
                    candidates.append((n1.id, n2.id, overall_sim))

        # Sort descending and do greedy one-to-one matching
        candidates.sort(key=lambda x: (-x[2], x[0], x[1]))
        used_src: set = set()
        used_tgt: set = set()
        matched: list[tuple[str, str, float]] = []

        for src_id, tgt_id, sim in candidates:
            if src_id not in used_src and tgt_id not in used_tgt:
                matched.append((src_id, tgt_id, sim))
                used_src.add(src_id)
                used_tgt.add(tgt_id)

        return matched

    def _refine_alignment(self, g1: PasgGraph, g2: PasgGraph,
                          candidates: list[tuple[str, str, float]]
                          ) -> list[tuple[str, str, float]]:
        """Step 2: Structural refinement."""
        refined: list[tuple[str, str, float]] = []
        src_map = {n.id: n for n in g1.nodes}
        tgt_map = {n.id: n for n in g2.nodes}

        src_neighbors = self._build_neighbor_map(g1)
        tgt_neighbors = self._build_neighbor_map(g2)

        for src_id, tgt_id, node_sim in candidates:
            src_node = src_map.get(src_id)
            tgt_node = tgt_map.get(tgt_id)
            if not src_node or not tgt_node:
                continue

            # Neighbor type distribution similarity
            src_nt = src_neighbors.get(src_id, defaultdict(int))
            tgt_nt = tgt_neighbors.get(tgt_id, defaultdict(int))

            all_types = set(src_nt.keys()) | set(tgt_nt.keys())

            structural_sim = 0.5  # default if no neighbors
            if all_types:
                src_total = sum(src_nt.values()) or 1
                tgt_total = sum(tgt_nt.values()) or 1
                dist_sim = 0.0
                for t in all_types:
                    src_prob = src_nt[t] / src_total
                    tgt_prob = tgt_nt[t] / tgt_total
                    dist_sim += min(src_prob, tgt_prob)
                structural_sim = dist_sim

            # Always keep the pair (structural check is lenient)
            combined = 0.7 * node_sim + 0.3 * structural_sim
            refined.append((src_id, tgt_id, combined))

        return refined

    def _build_neighbor_map(self, g: PasgGraph
                            ) -> dict[str, dict[PasgNodeType, int]]:
        """Build neighbor type distribution per node."""
        neighbors: dict[str, dict[PasgNodeType, int]] = defaultdict(lambda: defaultdict(int))
        node_map = {n.id: n for n in g.nodes}
        for edge in g.edges:
            src = node_map.get(edge.source_id)
            tgt = node_map.get(edge.target_id)
            if src and tgt:
                neighbors[edge.source_id][tgt.type] += 1
                neighbors[edge.target_id][src.type] += 1
        return neighbors

    def _compute_equivalence(self, g1: PasgGraph, g2: PasgGraph,
                              aligned: list[tuple[str, str, float]]) -> dict:
        """Step 3: Compute equivalence scores."""
        aligned_src = {s for s, _, _ in aligned}
        aligned_tgt = {t for _, t, _ in aligned}

        # Use pre-filter count for honest node retention
        total_src = g1.metadata.get("source_arch_entities", g1.node_count())
        node_ret = len(aligned_src) / max(1, total_src)
        edge_ret = self._edge_retention(g1, g2, aligned)
        path_ret = self._path_retention(g1, g2, aligned)

        overall = (self._w_node * node_ret +
                   self._w_edge * edge_ret +
                   self._w_path * path_ret)

        return {
            "node_retention": node_ret,
            "edge_retention": edge_ret,
            "path_retention": path_ret,
            "overall_score": overall,
            "aligned_source_nodes": len(aligned_src),
            "aligned_target_nodes": len(aligned_tgt),
            "total_source_nodes": g1.node_count(),
            "total_target_nodes": g2.node_count(),
            "total_source_edges": g1.edge_count(),
            "total_target_edges": g2.edge_count(),
        }

    def _edge_retention(self, g1: PasgGraph, g2: PasgGraph,
                        aligned: list[tuple[str, str, float]]) -> float:
        """Edge retention rate."""
        if g1.edge_count() == 0:
            return 1.0

        src_to_tgt = {s: t for s, t, _ in aligned}
        tgt_edge_set = set()
        for e in g2.edges:
            tgt_edge_set.add((e.source_id, e.target_id, e.type.value))

        retained = 0
        for e in g1.edges:
            tgt_u = src_to_tgt.get(e.source_id)
            tgt_v = src_to_tgt.get(e.target_id)
            if tgt_u and tgt_v:
                if (tgt_u, tgt_v, e.type.value) in tgt_edge_set:
                    retained += 1

        return retained / max(1, g1.edge_count())

    def _path_retention(self, g1: PasgGraph, g2: PasgGraph,
                        aligned: list[tuple[str, str, float]]) -> float:
        """Path retention rate."""
        if g1.edge_count() == 0:
            return 1.0

        src_to_tgt = {s: t for s, t, _ in aligned}
        tgt_edge_set = set()
        for e in g2.edges:
            tgt_edge_set.add((e.source_id, e.target_id))

        src_adj: dict[str, list[str]] = defaultdict(list)
        for e in g1.edges:
            src_adj[e.source_id].append(e.target_id)

        screen_nodes = [n.id for n in g1.nodes if n.type == PasgNodeType.SCREEN]

        total_paths = 0
        retained_paths = 0

        for start in screen_nodes:
            # BFS up to depth 3
            queue = [(start, [start])]
            visited_paths = set()
            while queue:
                current, path = queue.pop(0)
                if len(path) > 3:
                    continue
                for nxt in src_adj.get(current, []):
                    if nxt in path:
                        continue
                    new_path = path + [nxt]
                    path_key = tuple(new_path)
                    if path_key in visited_paths:
                        continue
                    visited_paths.add(path_key)

                    if len(new_path) >= 2:
                        total_paths += 1
                        mapped = [src_to_tgt.get(nid) for nid in new_path]
                        if None not in mapped:
                            valid = True
                            for i in range(len(mapped) - 1):
                                if (mapped[i], mapped[i + 1]) not in tgt_edge_set:
                                    valid = False
                                    break
                            if valid:
                                retained_paths += 1

                    if len(new_path) < 3:
                        queue.append((nxt, new_path))

        return retained_paths / max(1, total_paths)


# ═══════════════════════════════════════════════════════════════════════
# Alignment result
# ═══════════════════════════════════════════════════════════════════════

class AlignmentResult:
    """Complete alignment result with metadata."""

    def __init__(self, aligned_pairs: list[tuple[str, str, float]],
                 candidate_pairs: list[tuple[str, str, float]],
                 scores: dict,
                 src_graph: PasgGraph,
                 tgt_graph: PasgGraph):
        self.aligned_pairs = aligned_pairs
        self.candidate_pairs = candidate_pairs
        self.scores = scores
        self.src_graph = src_graph
        self.tgt_graph = tgt_graph

    @property
    def equivalence_score(self) -> float:
        return self.scores["overall_score"]

    def to_dict(self) -> dict:
        unaligned_src = [n.id for n in self.src_graph.nodes
                         if n.id not in {s for s, _, _ in self.aligned_pairs}]
        unaligned_tgt = [n.id for n in self.tgt_graph.nodes
                         if n.id not in {t for _, t, _ in self.aligned_pairs}]
        return {
            "scores": self.scores,
            "aligned_pairs": [
                {
                    "source_id": s, "target_id": t, "similarity": sim,
                    "source_name": self._name(self.src_graph, s),
                    "target_name": self._name(self.tgt_graph, t),
                    "type": self._type(self.src_graph, s),
                }
                for s, t, sim in self.aligned_pairs
            ],
            "unaligned_source": [
                {"id": n.id, "name": n.name, "type": n.type.value}
                for n in self.src_graph.nodes if n.id in unaligned_src
            ],
            "unaligned_target": [
                {"id": n.id, "name": n.name, "type": n.type.value}
                for n in self.tgt_graph.nodes if n.id in unaligned_tgt
            ],
        }

    def _name(self, g: PasgGraph, nid: str) -> str:
        n = g.get_node(nid)
        return n.name if n else "?"

    def _type(self, g: PasgGraph, nid: str) -> str:
        n = g.get_node(nid)
        return n.type.value if n else "?"

    def summary(self) -> str:
        s = self.scores
        return "\n".join([
            "=" * 60,
            "PASG Alignment Results",
            "=" * 60,
            f"Source: {s['total_source_nodes']} nodes, {s['total_source_edges']} edges",
            f"Target: {s['total_target_nodes']} nodes, {s['total_target_edges']} edges",
            f"Aligned: {s['aligned_source_nodes']} pairs",
            "",
            "Equivalence Scores:",
            f"  Node retention: {s['node_retention']:.4f}",
            f"  Edge retention: {s['edge_retention']:.4f}",
            f"  Path retention: {s['path_retention']:.4f}",
            f"  Overall:        {s['overall_score']:.4f}",
        ])
